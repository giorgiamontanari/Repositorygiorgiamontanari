﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Montanari.Gorgia._4H.ScheletrodiCodice.Classi
{
    class Network
    {
        public IPAddress NetAddress { get; set; }
        public IPAddress FirstHost { get; set; }
        public IPAddress LastHost { get; set; }
        public IPAddress BCastAdd { get; set; }
        public IPAddress SubNetMask { get; set; }

        /// <summary>
        /// method that takes an IpAdress and NetMask as input and returns an Id
        /// </summary>
        /// <param name="na"></param>
        /// <param name="nm"></param>
        /// <returns></returns>
        public int GetSubNetID(IPAddress na, NetMask nm)
        {
            return 0;
        }

        /// <summary>
        /// method that takes the first host as its input
        /// </summary>
        /// <param name="na"></param>
        /// <returns></returns>
        public IPAddress GetFirstHost(IPAddress na)
        {
            return na;
        }

        /// <summary>
        /// method that takes the last host as an input
        /// </summary>
        /// <param name="na"></param>
        /// <returns></returns>
        public IPAddress GetLastHost(IPAddress na)
        {
            return na;
        }

        /// <summary>
        /// method that takes BC as input
        /// </summary>
        /// <param name="na"></param>
        /// <returns></returns>
        public IPAddress GetBCastAdd(IPAddress na)
        {
            return na;
        }
    }
}
