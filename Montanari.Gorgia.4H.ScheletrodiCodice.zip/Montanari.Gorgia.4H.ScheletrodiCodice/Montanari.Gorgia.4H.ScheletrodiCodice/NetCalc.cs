﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Montanari.Gorgia._4H.ScheletrodiCodice.Classi
{
    class NetCalc
    {
        public IPAddress BaseAddress { get; set; }
        public NetMask SubNetMask { get; set; }

        /// <summary>
        /// method that takes as input an IPAdress, a netmask and an int and returns a new network
        /// </summary>
        /// <param name="BaseAddress"></param>
        /// <param name="SubNetMask"></param>
        /// <param name="NetNumber"></param>
        /// <returns></returns>
        public Network GetSpecificNet(IPAddress ba, NetMask nm, int nn)
        {
            return new Network();
        }

        /// <summary>
        /// method that takes an IPAdress, a netmask and returns a new network
        /// </summary>
        /// <param name="BaseAddress"></param>
        /// <param name="SubNetMask"></param>
        /// <returns></returns>
        public Network GetNetworks(IPAddress ba, NetMask nm)
        {
            return new Network();
        }

        /// <summary>
        /// method that takes two input strings
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="Mask"></param>
        /// <returns></returns>
        public string GetNSHBits(IPAddress IP, NetMask Mask)
        {
            return "";
        }

        /// <summary>
        /// method that takes two input strings
        /// </summary>
        /// <param name="IP"></param>
        /// <param name="Prefix"></param>
        /// <returns></returns>
        public string GetNSHBits(IPAddress IP, string Prefix)
        {
            return "";
        }
    }
}
