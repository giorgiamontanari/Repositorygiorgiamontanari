﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Montanari.Gorgia._4H.ScheletrodiCodice.Classi
{
    class IPAddress
    {
        public string Address { get; set; }

        /// <summary>
        /// method that converts a string of numbers to binary
        /// </summary>
        /// <param name="Address"></param>
        /// <returns></returns>
        public string ToBinary(string a)
        {
            return a;
        }

        /// <summary>
        /// method that converts a string of numbers to hexadecimal
        /// </summary>
        /// <param name="Address"></param>
        /// <returns></returns>
        public string ToHex(string a)
        {
            return a;
        }

        /// <summary>
        /// method that converts a string of numbers to an IP address with four bytes by means of four base numbers 10 separated by periods
        /// </summary>
        /// <param name="Address"></param>
        /// <returns></returns>
        public string ToDottedDecimal(string a)
        {
            return a;
        }

        /// <summary>
        /// method that converts a string of numbers into a dotted binary divided every 4 bytes by a dot
        /// </summary>
        /// <param name="Address"></param>
        /// <returns></returns>
        public string ToDottedBinary(string a)
        {
            return a;
        }

        /// <summary>
        /// method that converts a string of numbers to hexadecimal divided every 4 bytes by a dot
        /// </summary>
        /// <param name="Address"></param>
        /// <returns></returns>
        public string ToDottedHex(string a)
        {
            return a;
        }
    }
}
