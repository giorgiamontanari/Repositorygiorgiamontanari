﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Montanari.Gorgia._4H.ScheletrodiCodice.Classi
{
    class NetMask
    {
        public string Mask { get; set; }
        public string Prefix { get; set; }

        /// <summary>
        /// method that takes a string as input and returns a prefix
        /// </summary>
        /// <param name="Mask"></param>
        /// <returns></returns>
        public string GetPrefix(string Mask)
        {
            return Prefix;
        }

        /// <summary>
        /// method that takes a string as input and returns a mask
        /// </summary>
        /// <param name="Prefix"></param>
        /// <returns></returns>
        public string GetMask(string Prefix)
        {
            return Mask;
        }
    }
}
